/**
 * SafeMate v2.0 - Simple Diagnostic Lambda Function
 * 
 * Simple diagnostic function to test Lambda infrastructure
 * 
 * Version: V47.2-Diagnostic
 * Last Updated: 2025-10-02
 * 
 * @author SafeMate Development Team
 */

exports.handler = async (event) => {
    console.log('=== SIMPLE DIAGNOSTIC LAMBDA START ===');
    console.log('Event:', JSON.stringify(event, null, 2));
    
    try {
        // Handle different routes
        const path = event.path || event.requestContext?.path || '/';
        const method = event.httpMethod || event.requestContext?.httpMethod || 'GET';
        
        console.log(`Processing ${method} ${path}`);
        
        if (path === '/health' || path === '/preprod/health') {
            // Health check endpoint
            const result = {
                success: true,
                message: 'SafeMate v2 API is healthy',
                version: 'V47.2-Diagnostic',
                timestamp: new Date().toISOString(),
                environment: {
                    NODE_ENV: process.env.NODE_ENV,
                    AWS_REGION: process.env.AWS_REGION,
                    HEDERA_NETWORK: process.env.HEDERA_NETWORK,
                    HEDERA_ACCOUNT_ID: process.env.HEDERA_ACCOUNT_ID,
                    FOLDER_COLLECTION_TOKEN: process.env.FOLDER_COLLECTION_TOKEN,
                    SAFEMATE_FOLDERS_TABLE: process.env.SAFEMATE_FOLDERS_TABLE,
                    WALLET_KMS_KEY_ID: process.env.WALLET_KMS_KEY_ID
                }
            };
            
            console.log('Health check result:', JSON.stringify(result, null, 2));
            
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,x-cognito-token',
                    'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS'
                },
                body: JSON.stringify(result)
            };
        } else {
            // Default diagnostic response
            const result = {
                success: true,
                message: 'Diagnostic Lambda is working',
                timestamp: new Date().toISOString(),
                path: path,
                method: method,
                environment: {
                    NODE_ENV: process.env.NODE_ENV,
                    AWS_REGION: process.env.AWS_REGION,
                    HEDERA_NETWORK: process.env.HEDERA_NETWORK,
                    HEDERA_ACCOUNT_ID: process.env.HEDERA_ACCOUNT_ID,
                    FOLDER_COLLECTION_TOKEN: process.env.FOLDER_COLLECTION_TOKEN,
                    SAFEMATE_FOLDERS_TABLE: process.env.SAFEMATE_FOLDERS_TABLE,
                    WALLET_KMS_KEY_ID: process.env.WALLET_KMS_KEY_ID
                }
            };
            
            console.log('Diagnostic result:', JSON.stringify(result, null, 2));
            
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,x-cognito-token',
                    'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS'
                },
                body: JSON.stringify(result)
            };
        }
        
    } catch (error) {
        console.error('Diagnostic Lambda Error:', error);
        
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,x-cognito-token',
                'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS'
            },
            body: JSON.stringify({ success: false, error: error.message, stack: error.stack })
        };
    } finally {
        console.log('=== SIMPLE DIAGNOSTIC LAMBDA END ===');
    }
};