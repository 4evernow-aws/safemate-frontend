exports.handler = async (event) => {
  console.log('Lambda started successfully');
  
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify({ 
      status: 'alive',
      message: 'Lambda is working',
      timestamp: new Date().toISOString()
    })
  };
};
