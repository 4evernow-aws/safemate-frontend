// Diagnostic Lambda function to debug authentication issues
exports.handler = async (event) => {
  console.log('Full event:', JSON.stringify(event, null, 2));
  console.log('Headers:', JSON.stringify(event.headers, null, 2));
  
  const { httpMethod, path, body, headers } = event;
  
  // CORS headers
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,x-cognito-token',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
  };
  
  // Handle preflight requests
  if (httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'CORS preflight' })
    };
  }
  
  // Check for token in all possible locations
  const token = 
    event.headers['x-cognito-token'] ||           // Most common
    event.headers['X-Cognito-Token'] ||           // Before lowercasing
    event.headers['authorization'] ||             // Alternative
    event.headers['Authorization'] ||             // Before lowercasing
    event.queryStringParameters?.token ||         // Query string
    (body ? JSON.parse(body).token : null);       // Body
  
  console.log('Token found:', token ? 'Yes' : 'No');
  console.log('Token value:', token ? token.substring(0, 50) + '...' : 'None');
  
  // Diagnostic response
  const diagnosticResponse = {
    success: true,
    message: 'Diagnostic Lambda is working',
    version: 'V48.0-DIAGNOSTIC',
    timestamp: new Date().toISOString(),
    diagnostics: {
      httpMethod,
      path,
      hasBody: !!body,
      hasHeaders: !!headers,
      tokenFound: !!token,
      tokenLength: token ? token.length : 0,
      allHeaders: event.headers,
      environment: {
        NODE_ENV: process.env.NODE_ENV || 'undefined',
        VERSION: process.env.VERSION || 'undefined',
        HEDERA_ACCOUNT_ID: process.env.HEDERA_ACCOUNT_ID || 'undefined'
      }
    }
  };
  
  // If no token, return unauthorized
  if (!token) {
    return {
      statusCode: 401,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        success: false,
        message: "Unauthorized - No token found",
        diagnostics: diagnosticResponse.diagnostics
      })
    };
  }
  
  // If token found, return success with diagnostics
  return {
    statusCode: 200,
    headers: {
      ...corsHeaders,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(diagnosticResponse)
  };
};
