/**
 * SafeMate v2.0 - Hedera Service Lambda Function
 * 
 * Environment: preprod
 * Function: preprod-safemate-hedera-service
 * Purpose: Handle Hedera blockchain operations including wallet creation, NFT operations, and file management
 * 
 * Version: V47.2-FINAL
 * Last Updated: 2025-10-02
 * Status: EMERGENCY RECOVERY - Minimal working version
 * 
 * @author SafeMate Development Team
 */

// AWS SDK imports
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, PutCommand, QueryCommand, DeleteCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const { KMSClient, DecryptCommand, EncryptCommand } = require('@aws-sdk/client-kms');

// Initialize AWS clients
const dynamodbClient = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(dynamodbClient);
const kms = new KMSClient({});

// Environment variables
const WALLET_KEYS_TABLE = process.env.WALLET_KEYS_TABLE || 'default-safemate-wallet-keys';
const WALLET_METADATA_TABLE = process.env.WALLET_METADATA_TABLE || 'default-safemate-wallet-metadata';
const WALLET_KMS_KEY_ID = process.env.WALLET_KMS_KEY_ID;
const HEDERA_NETWORK = process.env.HEDERA_NETWORK || 'testnet';
const SAFEMATE_FOLDERS_TABLE = process.env.SAFEMATE_FOLDERS_TABLE || 'default-safemate-folders';

exports.handler = async (event) => {
    console.log('=== SafeMate Hedera Service Lambda START ===');
    console.log('Event:', JSON.stringify(event, null, 2));
    
    try {
        // Handle different routes
        const path = event.path || event.requestContext?.path || '/';
        const method = event.httpMethod || event.requestContext?.httpMethod || 'GET';
        
        console.log(`Processing ${method} ${path}`);
        
        if (path === '/health' || path === '/preprod/health') {
            // Health check endpoint
            const result = {
                success: true,
                message: 'SafeMate v2 API is healthy',
                version: 'V47.2-Recovery',
                timestamp: new Date().toISOString(),
                environment: {
                    NODE_ENV: process.env.NODE_ENV,
                    AWS_REGION: process.env.AWS_REGION,
                    HEDERA_NETWORK: process.env.HEDERA_NETWORK,
                    HEDERA_ACCOUNT_ID: process.env.HEDERA_ACCOUNT_ID,
                    FOLDER_COLLECTION_TOKEN: process.env.FOLDER_COLLECTION_TOKEN,
                    SAFEMATE_FOLDERS_TABLE: process.env.SAFEMATE_FOLDERS_TABLE,
                    WALLET_KMS_KEY_ID: process.env.WALLET_KMS_KEY_ID,
                    WALLET_KEYS_TABLE: process.env.WALLET_KEYS_TABLE,
                    WALLET_METADATA_TABLE: process.env.WALLET_METADATA_TABLE
                }
            };
            
            console.log('Health check result:', JSON.stringify(result, null, 2));
            
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,x-cognito-token',
                    'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS'
                },
                body: JSON.stringify(result)
            };
        } else {
            // Default response
            const result = {
                success: true,
                message: 'SafeMate Hedera Service is running',
                timestamp: new Date().toISOString(),
                path: path,
                method: method,
                note: 'This is a minimal recovery version. Full functionality will be restored gradually.'
            };
            
            console.log('Default result:', JSON.stringify(result, null, 2));
            
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,x-cognito-token',
                    'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS'
                },
                body: JSON.stringify(result)
            };
        }
        
    } catch (error) {
        console.error('Lambda Error:', error);
        
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,x-cognito-token',
                'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS'
            },
            body: JSON.stringify({ success: false, error: error.message, stack: error.stack })
        };
    } finally {
        console.log('=== SafeMate Hedera Service Lambda END ===');
    }
};